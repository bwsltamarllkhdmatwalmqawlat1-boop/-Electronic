/* Service Worker — يخزّن كل ملفات التطبيق ليعمل بلا إنترنت */
const V = "sig-stamp-v3";
const CORE = ["./", "index.html", "manifest.webmanifest", "pdf.min.mjs", "pdf.worker.min.mjs", "pdf-lib.min.js",
  "icon-192.png", "icon-512.png", "maskable-512.png", "apple-touch-icon.png"];
const EXTRA = [
 "jbig2.wasm",
 "openjpeg.wasm",
 "qcms_bg.wasm",
 "quickjs-eval.wasm",
 "FoxitDingbats.pfb",
 "FoxitFixed.pfb",
 "FoxitFixedBold.pfb",
 "FoxitFixedBoldItalic.pfb",
 "FoxitFixedItalic.pfb",
 "FoxitSerif.pfb",
 "FoxitSerifBold.pfb",
 "FoxitSerifBoldItalic.pfb",
 "FoxitSerifItalic.pfb",
 "FoxitSymbol.pfb",
 "LiberationSans-Bold.ttf",
 "LiberationSans-BoldItalic.ttf",
 "LiberationSans-Italic.ttf",
 "LiberationSans-Regular.ttf"
];

self.addEventListener("install", e => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    await c.addAll(CORE);
    await Promise.allSettled(EXTRA.map(u => c.add(u)));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== V) await caches.delete(k);
    await self.clients.claim();
  })());
});

/* الكاش أولًا (سريع وبلا نت)، وإن لم يوجد الملف يُجلب من الشبكة ويُحفظ */
self.addEventListener("fetch", e => {
  const r = e.request;
  if (r.method !== "GET" || new URL(r.url).origin !== location.origin) return;
  e.respondWith((async () => {
    const hit = await caches.match(r, { ignoreSearch: true });
    if (hit) return hit;
    try {
      const res = await fetch(r);
      if (res && res.ok) (await caches.open(V)).put(r, res.clone());
      return res;
    } catch (err) {
      if (r.mode === "navigate") return (await caches.match("index.html")) || Response.error();
      return Response.error();
    }
  })());
});
